package com.social.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.social.demo.entity.User;
import com.social.demo.repository.UserRepository;
import com.social.demo.service.UserService;

@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
	UserService userService;
	
	@GetMapping
	public List<User> getUsers(){
		List<User> users = userService.getAllUsers();
		return users;
	}
	
	@GetMapping("/email/{email}")
	public User getUserbyEmail(@PathVariable String email){
		User users = userService.getUserByEmail(email);
		return users;
	}
	
	@GetMapping("/location/{location}")
	public List<User> getUser(@PathVariable String location){
		List<User> user = userService.getUserByLocation(location); 
		return user;	
	}
	
	@GetMapping("/{userid}")
	public Optional<User> getUser(@PathVariable Long userid){
		Optional<User> userbyid = userService.getUserbyId(userid); 
		return userbyid;	
	}
	
	@PostMapping()
	public User addUser(@RequestBody User user){
		return this.userService.addUser(user);
	}
	
	
    @PutMapping()
    public String updateUser(@RequestBody User user) {
    	this.userService.updateUser(user);
    	return "User Updated";
    }
    
    
    @DeleteMapping("/{userId}")
    public String deleteUser(@PathVariable Long userId){
    	Optional<User> user = userService.getUserbyId(userId);
    	if(user!=null) {
    		userService.deleteUser(userId);
    		return "user deleted";
    	}
    	else {
    		return "User not found";
    		
    		
    	}
    }
	
}