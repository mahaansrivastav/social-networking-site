package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.demo.entity.User;
import com.social.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepo;

	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public Optional<User> getUserbyId(Long id) {
		return userRepo.findById(id);
	}


	@Override
	public User addUser(User user) {
		userRepo.save(user);
		return null;
	}

	@Override
	public User updateUser(User user) {
		userRepo.save(user);
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(long userid) {
		userRepo.deleteById(userid);
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userRepo.findByEmail(email);
	}

	@Override
	public List<User> getUserByLocation(String Location) {
		// TODO Auto-generated method stub
		return userRepo.findByLocation(Location);
	}
	


	
	

}
