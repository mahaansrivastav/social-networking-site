package com.social.demo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.social.demo.entity.Message;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long>{
//	public Optional<Message> findByRecipient_id(Long recipient_id);

}
