package com.social.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.social.demo.entity.UserGroup;
import com.social.demo.service.GroupService;
@CrossOrigin(origins = "http://localhost:3000/")
@RestController
@RequestMapping("/groups")
public class GroupController {
	@Autowired
	GroupService groupService;
	
	@GetMapping
	public List<UserGroup>  getAllGroups(){
		return groupService.getAllGroups();
	}
	
	@GetMapping("/{id}")
	public Optional<UserGroup> getUserGroup(@PathVariable Long id) {
		return groupService.getGroupById(id);
	}
	
	@PostMapping
	public UserGroup createGroup(@RequestBody UserGroup group) {
		return groupService.createGroup(group);
		
	}

}
