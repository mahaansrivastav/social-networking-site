package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.social.demo.entity.Post;

@Service
public interface PostService {
	
public List<Post> getAllPosts();
	
	public Optional<Post> getPostbyId(Long id);
	public String deletePost(Long id);
	public Post createPost(Post post);
	public List<Post> getPostByUserId(Long user_id);

	public Post updatePost(Post post);
}
