package com.social.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.social.demo.entity.UserGroup;

@Repository
public interface GroupRepository extends JpaRepository<UserGroup, Long> {

}
