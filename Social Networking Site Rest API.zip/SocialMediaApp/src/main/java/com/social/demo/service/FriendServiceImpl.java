package com.social.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.demo.entity.Friend;
import com.social.demo.repository.FriendRepository;

@Service
public class FriendServiceImpl implements FriendService{
	
	@Autowired
	FriendRepository friendRepo;

	@Override
	public List<Friend> getAllFriends() {
		// TODO Auto-generated method stub
		return friendRepo.findAll();
	}

	@Override
	public Friend addFriend(Friend friend) {
		// TODO Auto-generated method stub
		return friendRepo.save(friend);
	}


	@Override
	public Friend updateFriend(Friend friend) {
		// TODO Auto-generated method stub
		return friendRepo.save(friend);
	}

	@Override
	public void deleteFriend(long id) {
		// TODO Auto-generated method stub
		friendRepo.deleteById(null);
	}

	
	//need to return friends of an user_id
//	@Override
//	public List<Friend> getFriendByUserId(Long id) {
//		// TODO Auto-generated method stub
//		return friendRepo.findByUser_id(id);
//
//	}
	
	

}
