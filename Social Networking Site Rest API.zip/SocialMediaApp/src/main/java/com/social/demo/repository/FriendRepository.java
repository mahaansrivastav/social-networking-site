package com.social.demo.repository;

import java.util.List;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.social.demo.entity.Friend;


public interface FriendRepository extends JpaRepository<Friend, Long>{

	//public List<Friend> findByUser_id(Long id);
}
