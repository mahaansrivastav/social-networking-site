package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.social.demo.entity.Message;
import com.social.demo.entity.User;

@Service
public interface MessageService {
	
	public List<Message> getAllMessages();
	
	public Optional<Message> getMessagebyId(Long id);

	public Message sendMessage(Message message);
		
	public String deleteMessage(Long id);

//	public Optional<Message> getMessagebyUserId(Long id);

}
