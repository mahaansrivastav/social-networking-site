package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.social.demo.entity.UserGroup;

@Service
public interface GroupService {
	public UserGroup createGroup(UserGroup group); 
	public List<UserGroup> getAllGroups();
	public Optional<UserGroup> getGroupById(Long id);
	

}
