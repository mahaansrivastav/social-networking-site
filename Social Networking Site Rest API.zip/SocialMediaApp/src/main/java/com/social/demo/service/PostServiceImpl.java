package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.demo.entity.Post;
import com.social.demo.repository.PostRepository;

@Service
public class PostServiceImpl implements PostService {
	@Autowired
	PostRepository postRepo;

	@Override
	public List<Post> getAllPosts() {
		
		// TODO Auto-generated method stub
		return postRepo.findAll();
	}

	@Override
	public Optional<Post> getPostbyId(Long id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public Post createPost(Post post) {
		// TODO Auto-generated method stub
		return postRepo.save(post);
	}

	@Override
	public String deletePost(Long id) {
		// TODO Auto-generated method stub
			postRepo.deleteById(id);
		return "Post Deleted Sucessfully" ;
	}

	@Override
	public List<Post> getPostByUserId(Long user_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Post updatePost(Post post) {
		// TODO Auto-generated method stub
		return postRepo.save(post);
	}

	

}
