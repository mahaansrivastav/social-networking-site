package com.social.demo.service;

import java.util.List;

import com.social.demo.entity.Friend;

public interface FriendService {

	public List<Friend> getAllFriends();
	public Friend addFriend(Friend friend);
	//public List<Friend> getFriendByUserId(Long id);
	public Friend updateFriend(Friend friend);
	public void deleteFriend(long id);

}
