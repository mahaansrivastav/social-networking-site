package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.demo.entity.Message;
import com.social.demo.repository.MessageRepository;

@Service
public class MessageServiceImpl implements MessageService {

	@Autowired
	MessageRepository messageRepo;

	@Override
	public List<Message> getAllMessages() {
		return messageRepo.findAll();

	}

	@Override
	public Optional<Message> getMessagebyId(Long id) {
		return messageRepo.findById(id);
	}

//	@Override
//	public Optional<Message> getMessagebyUserId(Long id) {
//		// TODO Auto-generated method stub
//		return messageRepo.findByRecipient_id(id);
//	}

	@Override
	public Message sendMessage(Message message) {
		return messageRepo.save(message);
	}

	@Override
	public String deleteMessage(Long id) {
		messageRepo.deleteById(id);
		return "Messege deleted Sucessfully";
	}

}
