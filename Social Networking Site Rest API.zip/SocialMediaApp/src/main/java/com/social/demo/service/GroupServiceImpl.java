package com.social.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.social.demo.entity.UserGroup;
import com.social.demo.repository.GroupRepository;

@Service
public class GroupServiceImpl implements GroupService{
	
	@Autowired
	GroupRepository groupRepo;

	@Override
	public UserGroup createGroup(UserGroup group) {
		
		// TODO Auto-generated method stub
		return groupRepo.save(group);
	}

	@Override
	public List<UserGroup> getAllGroups() {
		// TODO Auto-generated method stub
		return groupRepo.findAll();
	}

	@Override
	public Optional<UserGroup> getGroupById(Long id) {
		// TODO Auto-generated method stub
		return groupRepo.findById(id);
	}

}
